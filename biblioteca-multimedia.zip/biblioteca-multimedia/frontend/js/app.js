const API = "/api/medios";
const $ = selector => document.querySelector(selector);

let allMedia = [];
let currentView = "catalogo";
let currentType = "";
let favorites = new Set(JSON.parse(localStorage.getItem("biblioteca_favoritos") || "[]"));

const labels = {
  libro: "Libro",
  audiolibro: "Audiolibro",
  video: "Video",
  musica: "Música"
};

function escapeHTML(value = "") {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  })[char]);
}

function toast(message) {
  const element = $("#toast");
  element.textContent = message;
  element.classList.add("show");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => element.classList.remove("show"), 2800);
}

async function request(url, options = {}) {
  const response = await fetch(url, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "No se pudo completar la operación.");
  return data;
}

function coverMarkup(item) {
  const cover = item.caratula_url;
  if (cover) {
    return `<img src="${escapeHTML(cover)}" alt="Carátula de ${escapeHTML(item.titulo)}" onerror="this.remove()">`;
  }
  const symbols = { libro: "▤", audiolibro: "♫", video: "▶", musica: "♫" };
  return `<div class="cover-placeholder">${symbols[item.tipo] || "▦"}</div>`;
}

function cardMarkup(item) {
  const id = String(item._id);
  const favorite = favorites.has(id);
  const hasFile = Boolean(item.archivo_url);
  const canPlay = hasFile && ["audiolibro", "musica", "video", "libro"].includes(item.tipo);
  const action = canPlay
    ? `<button class="icon-btn" title="Abrir contenido" data-action="open" data-id="${id}">▶</button>`
    : "";
  return `
    <article class="media-card">
      <div class="cover-wrap">
        ${coverMarkup(item)}
        <span class="type-badge">${labels[item.tipo] || escapeHTML(item.tipo)}</span>
        <button class="favorite-btn ${favorite ? "is-favorite" : ""}" title="Favorito" data-action="favorite" data-id="${id}">${favorite ? "♥" : "♡"}</button>
      </div>
      <div class="card-body">
        <div class="card-meta">${escapeHTML(item.genero || "Multimedia")}</div>
        <h3>${escapeHTML(item.titulo)}</h3>
        <div class="card-author">${escapeHTML(item.autor || "Autor no especificado")}</div>
        <p class="card-description">${escapeHTML(item.descripcion || "Sin descripción disponible.")}</p>
        <div class="card-bottom">
          <span class="card-year">${item.anio_publicacion || "Año no indicado"}</span>
          <div class="card-actions">
            ${action}
            <button class="icon-btn" title="Editar" data-action="edit" data-id="${id}">✎</button>
            <button class="icon-btn delete" title="Eliminar" data-action="delete" data-id="${id}">⌫</button>
          </div>
        </div>
      </div>
    </article>`;
}

function renderGrid(element, items) {
  element.innerHTML = items.map(cardMarkup).join("");
}

function getFilteredItems() {
  const query = $("#searchInput").value.trim().toLocaleLowerCase("es");
  const type = $("#typeFilter").value || currentType;
  const genre = $("#genreFilter").value;
  return allMedia.filter(item => {
    const searchable = [item.titulo, item.autor, item.genero, item.descripcion, ...(item.etiquetas || [])]
      .join(" ").toLocaleLowerCase("es");
    return (!query || searchable.includes(query))
      && (!type || item.tipo === type)
      && (!genre || item.genero === genre);
  });
}

function updateGenres() {
  const select = $("#genreFilter");
  const current = select.value;
  const genres = [...new Set(allMedia.map(x => x.genero).filter(Boolean))].sort();
  select.innerHTML = `<option value="">Todos los géneros</option>` +
    genres.map(g => `<option value="${escapeHTML(g)}">${escapeHTML(g)}</option>`).join("");
  if (genres.includes(current)) select.value = current;
}

function renderCatalog() {
  const items = getFilteredItems();
  renderGrid($("#mediaGrid"), items);
  $("#resultCount").textContent = `${items.length} ${items.length === 1 ? "recurso" : "recursos"}`;
  $("#emptyState").classList.toggle("hidden", items.length !== 0);
  $("#mediaGrid").classList.toggle("hidden", items.length === 0);
}

function updateStats() {
  const count = type => allMedia.filter(x => x.tipo === type).length;
  $("#totalStat").textContent = allMedia.length;
  $("#booksStat").textContent = count("libro");
  $("#audioStat").textContent = count("audiolibro") + count("musica");
  $("#videosStat").textContent = count("video");
  $("#statsTotal").textContent = allMedia.length;
  $("#statsBooks").textContent = count("libro");
  $("#statsAudiobooks").textContent = count("audiolibro");
  $("#statsVideos").textContent = count("video");
  $("#statsMusic").textContent = count("musica");

  const values = [
    ["Libros", count("libro")], ["Audiolibros", count("audiolibro")],
    ["Videos", count("video")], ["Música", count("musica")]
  ];
  $("#distributionChart").innerHTML = values.map(([name, value]) => {
    const width = allMedia.length ? value / allMedia.length * 100 : 0;
    return `<div class="bar-row"><span>${name}</span><div class="bar-track"><div class="bar-fill" style="width:${width}%"></div></div><strong>${value}</strong></div>`;
  }).join("");
}

async function loadMedia() {
  try {
    allMedia = await request(API);
    updateGenres();
    updateStats();
    renderCatalog();
    renderFavorites();
  } catch (error) {
    $("#mediaGrid").innerHTML = `<div class="loading-state">No se pudo conectar con MongoDB. ${escapeHTML(error.message)}</div>`;
    toast(error.message);
  }
}

function renderFavorites() {
  const items = allMedia.filter(item => favorites.has(String(item._id)));
  renderGrid($("#favoritesGrid"), items);
  $("#favoritesEmpty").classList.toggle("hidden", items.length > 0);
  $("#favoritesGrid").classList.toggle("hidden", items.length === 0);
}

function setView(view) {
  currentView = view;
  $("#catalogView").classList.toggle("hidden", view !== "catalogo");
  $("#favoritesView").classList.toggle("hidden", view !== "favoritos");
  $("#statisticsView").classList.toggle("hidden", view !== "estadisticas");
  document.querySelectorAll(".nav-item").forEach(button => button.classList.remove("active"));
  const active = document.querySelector(`.nav-item[data-view="${view}"]`);
  if (active) active.classList.add("active");
  const names = { catalogo: "Catálogo", favoritos: "Favoritos", estadisticas: "Estadísticas" };
  $("#breadcrumbCurrent").textContent = names[view] || "Catálogo";
  $("#sidebar").classList.remove("open");
}

function setType(type) {
  currentType = type;
  $("#typeFilter").value = type;
  setView("catalogo");
  $("#catalogTitle").textContent = type ? labels[type] : "Explora el catálogo";
  document.querySelectorAll(".filter-nav").forEach(button => {
    button.classList.toggle("active", button.dataset.type === type);
  });
  renderCatalog();
}

function openForm(item = null) {
  $("#mediaForm").reset();
  $("#mediaId").value = item?._id || "";
  $("#formTitle").textContent = item ? "Editar recurso" : "Agregar recurso";
  $("#saveButton").textContent = item ? "Guardar cambios" : "Guardar recurso";
  if (item) {
    $("#titulo").value = item.titulo || "";
    $("#tipo").value = item.tipo || "libro";
    $("#autor").value = item.autor || "";
    $("#genero").value = item.genero || "";
    $("#anio").value = item.anio_publicacion ?? "";
    $("#paginas").value = item.paginas ?? "";
    $("#duracion").value = item.duracion_minutos ?? "";
    $("#descripcion").value = item.descripcion || "";
    $("#etiquetas").value = (item.etiquetas || []).join(", ");
  }
  $("#mediaDialog").showModal();
}

function closeForm() { $("#mediaDialog").close(); }

async function saveMedia(event) {
  event.preventDefault();
  const id = $("#mediaId").value;
  const formData = new FormData($("#mediaForm"));
  const url = id ? `${API}/${id}` : API;
  const method = id ? "PUT" : "POST";
  $("#saveButton").disabled = true;
  $("#saveButton").textContent = "Guardando...";
  try {
    await request(url, { method, body: formData });
    closeForm();
    await loadMedia();
    toast(id ? "Recurso actualizado correctamente." : "Recurso agregado correctamente.");
  } catch (error) {
    toast(error.message);
  } finally {
    $("#saveButton").disabled = false;
    $("#saveButton").textContent = id ? "Guardar cambios" : "Guardar recurso";
  }
}

async function handleCardAction(event) {
  const button = event.target.closest("[data-action]");
  if (!button) return;
  const { action, id } = button.dataset;
  const item = allMedia.find(x => String(x._id) === id);
  if (!item) return;

  if (action === "favorite") {
    favorites.has(id) ? favorites.delete(id) : favorites.add(id);
    localStorage.setItem("biblioteca_favoritos", JSON.stringify([...favorites]));
    renderCatalog();
    renderFavorites();
  } else if (action === "edit") {
    openForm(item);
  } else if (action === "delete") {
    if (!confirm(`¿Seguro que deseas eliminar "${item.titulo}"?`)) return;
    try {
      await request(`${API}/${id}`, { method: "DELETE" });
      favorites.delete(id);
      localStorage.setItem("biblioteca_favoritos", JSON.stringify([...favorites]));
      await loadMedia();
      toast("Recurso eliminado.");
    } catch (error) { toast(error.message); }
  } else if (action === "open") {
    openPlayer(item);
  }
}

function openPlayer(item) {
  $("#playerTitle").textContent = item.titulo;
  const url = item.archivo_url;
  const content = $("#playerContent");
  if (!url) {
    content.innerHTML = `<p class="no-file">Este registro todavía no tiene un archivo multimedia asociado.<br>Edítalo para cargar el archivo.</p>`;
  } else if (item.tipo === "musica" || item.tipo === "audiolibro") {
    content.innerHTML = `<audio controls autoplay src="${escapeHTML(url)}">Tu navegador no soporta audio.</audio>`;
  } else if (item.tipo === "video") {
    content.innerHTML = `<video controls autoplay src="${escapeHTML(url)}">Tu navegador no soporta video.</video>`;
  } else {
    content.innerHTML = `<iframe src="${escapeHTML(url)}" title="${escapeHTML(item.titulo)}"></iframe>`;
  }
  $("#playerDialog").showModal();
}

function bindEvents() {
  document.querySelectorAll(".nav-item[data-view]").forEach(button =>
    button.addEventListener("click", () => setView(button.dataset.view))
  );
  document.querySelectorAll(".filter-nav").forEach(button =>
    button.addEventListener("click", () => setType(button.dataset.type))
  );
  $("#searchInput").addEventListener("input", renderCatalog);
  $("#typeFilter").addEventListener("change", () => {
    currentType = $("#typeFilter").value;
    $("#catalogTitle").textContent = currentType ? labels[currentType] : "Explora el catálogo";
    renderCatalog();
  });
  $("#genreFilter").addEventListener("change", renderCatalog);
  $("#mediaGrid").addEventListener("click", handleCardAction);
  $("#favoritesGrid").addEventListener("click", handleCardAction);
  $("#addButton").addEventListener("click", () => openForm());
  $("#mediaForm").addEventListener("submit", saveMedia);
  $("#closeForm").addEventListener("click", closeForm);
  $("#cancelForm").addEventListener("click", closeForm);
  $("#closePlayer").addEventListener("click", () => $("#playerDialog").close());
  $("#mobileMenu").addEventListener("click", () => $("#sidebar").classList.toggle("open"));
  document.addEventListener("keydown", event => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
      event.preventDefault();
      $("#searchInput").focus();
    }
  });
}

bindEvents();
loadMedia();
