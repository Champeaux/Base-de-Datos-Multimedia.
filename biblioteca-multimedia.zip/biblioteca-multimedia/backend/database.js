const { MongoClient } = require("mongodb");

let client;
let database;

async function connectDB() {
  if (database) return database;

  const uri = process.env.MONGO_URI;
  const dbName = process.env.DB_NAME || "biblioteca_multimedia";

  if (!uri) {
    throw new Error("No se encontró MONGO_URI. Revisa tu archivo .env");
  }

  client = new MongoClient(uri);
  await client.connect();
  database = client.db(dbName);

  // Normaliza el valor usado en el seed original ("música") al tipo "musica".
  await database.collection("medios").updateMany(
    { tipo: "música" },
    { $set: { tipo: "musica" } }
  );

  // Índices para acelerar filtros y búsquedas.
  await database.collection("medios").createIndex({ titulo: 1 });
  await database.collection("medios").createIndex({ tipo: 1 });
  await database.collection("medios").createIndex({ genero: 1 });
  await database.collection("medios").createIndex({ autor: 1 });

  console.log(`MongoDB conectado: ${dbName}`);
  return database;
}

function getDB() {
  if (!database) throw new Error("La base de datos todavía no está conectada.");
  return database;
}

async function closeDB() {
  if (client) await client.close();
}

module.exports = { connectDB, getDB, closeDB };
