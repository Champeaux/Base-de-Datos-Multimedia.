const express = require("express");
const path = require("path");
const fs = require("fs");
const multer = require("multer");
const { ObjectId } = require("mongodb");
const { getDB } = require("../database");

const router = express.Router();
const ROOT = path.resolve(__dirname, "../..");
const STORAGE = path.join(ROOT, "almacenamiento");

const folders = {
  libro: "libros",
  audiolibro: "audiolibros",
  video: "videos",
  musica: "musica"
};

function ensureStorage() {
  ["libros", "audiolibros", "videos", "musica", "caratulas"].forEach(folder => {
    fs.mkdirSync(path.join(STORAGE, folder), { recursive: true });
  });
}
ensureStorage();

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const type = folders[req.body.tipo] || "otros";
    const folder = file.fieldname === "caratula"
      ? "caratulas"
      : type;
    fs.mkdirSync(path.join(STORAGE, folder), { recursive: true });
    cb(null, path.join(STORAGE, folder));
  },
  filename: (req, file, cb) => {
    const safe = file.originalname
      .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-zA-Z0-9._-]/g, "_");
    cb(null, `${Date.now()}-${safe}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 100 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = [
      "application/pdf", "audio/mpeg", "audio/mp3", "audio/wav",
      "audio/ogg", "video/mp4", "video/webm", "image/jpeg",
      "image/png", "image/webp"
    ];
    if (allowed.includes(file.mimetype)) return cb(null, true);
    cb(new Error("Formato no permitido. Usa PDF, MP3, WAV, MP4, WEBM o imágenes JPG/PNG/WEBP."));
  }
});

function cleanText(value) {
  return typeof value === "string" ? value.trim() : "";
}

function parsePayload(body, files = {}) {
  const tipo = cleanText(body.tipo).toLowerCase();
  if (!folders[tipo]) throw new Error("Selecciona un tipo de recurso válido.");

  const titulo = cleanText(body.titulo);
  const autor = cleanText(body.autor);
  if (!titulo || !autor) throw new Error("El título y el autor son obligatorios.");

  const etiquetas = cleanText(body.etiquetas)
    .split(",").map(x => x.trim()).filter(Boolean);

  const anio = body.anio_publicacion === "" || body.anio_publicacion == null
    ? null : Number(body.anio_publicacion);
  const paginas = body.paginas === "" || body.paginas == null
    ? null : Number(body.paginas);
  const duracion = body.duracion_minutos === "" || body.duracion_minutos == null
    ? null : Number(body.duracion_minutos);

  if (anio !== null && (!Number.isInteger(anio) || anio < 0 || anio > 3000)) {
    throw new Error("El año de publicación no es válido.");
  }

  const item = {
    titulo,
    tipo,
    autor,
    genero: cleanText(body.genero),
    anio_publicacion: anio,
    paginas: Number.isFinite(paginas) ? paginas : null,
    duracion_minutos: Number.isFinite(duracion) ? duracion : null,
    descripcion: cleanText(body.descripcion),
    etiquetas,
    actualizado_en: new Date()
  };

  if (files.archivo?.[0]) {
    const relative = path.relative(ROOT, files.archivo[0].path).split(path.sep).join("/");
    item.archivo_url = `/${relative}`;
  }
  if (files.caratula?.[0]) {
    const relative = path.relative(ROOT, files.caratula[0].path).split(path.sep).join("/");
    item.caratula_url = `/${relative}`;
  }

  return item;
}

function makeFilter(query) {
  const filter = {};
  const term = cleanText(query.q);
  const tipo = cleanText(query.tipo);
  const genero = cleanText(query.genero);

  if (term) {
    const safe = term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const regex = new RegExp(safe, "i");
    filter.$or = [
      { titulo: regex }, { autor: regex }, { descripcion: regex },
      { genero: regex }, { etiquetas: regex }
    ];
  }
  if (tipo && folders[tipo]) filter.tipo = tipo;
  if (genero) filter.genero = genero;
  return filter;
}

// GET /api/medios - catálogo con búsqueda y filtros.
router.get("/", async (req, res, next) => {
  try {
    const db = getDB();
    const items = await db.collection("medios")
      .find(makeFilter(req.query))
      .sort({ actualizado_en: -1, titulo: 1 })
      .toArray();
    res.json(items);
  } catch (err) { next(err); }
});

// GET /api/medios/estadisticas
router.get("/estadisticas", async (req, res, next) => {
  try {
    const collection = getDB().collection("medios");
    const [total, porTipo, recientes] = await Promise.all([
      collection.countDocuments(),
      collection.aggregate([
        { $group: { _id: "$tipo", cantidad: { $sum: 1 } } }
      ]).toArray(),
      collection.find().sort({ _id: -1 }).limit(5).toArray()
    ]);
    res.json({ total, porTipo, recientes });
  } catch (err) { next(err); }
});

// GET /api/medios/:id
router.get("/:id", async (req, res, next) => {
  try {
    if (!ObjectId.isValid(req.params.id)) return res.status(400).json({ error: "Identificador inválido." });
    const item = await getDB().collection("medios").findOne({ _id: new ObjectId(req.params.id) });
    if (!item) return res.status(404).json({ error: "Recurso no encontrado." });
    res.json(item);
  } catch (err) { next(err); }
});

// POST /api/medios - crear recurso.
router.post("/", upload.fields([{ name: "archivo", maxCount: 1 }, { name: "caratula", maxCount: 1 }]), async (req, res, next) => {
  try {
    const item = parsePayload(req.body, req.files || {});
    item.creado_en = new Date();
    const result = await getDB().collection("medios").insertOne(item);
    res.status(201).json({ ...item, _id: result.insertedId });
  } catch (err) { next(err); }
});

// PUT /api/medios/:id - editar recurso.
router.put("/:id", upload.fields([{ name: "archivo", maxCount: 1 }, { name: "caratula", maxCount: 1 }]), async (req, res, next) => {
  try {
    if (!ObjectId.isValid(req.params.id)) return res.status(400).json({ error: "Identificador inválido." });
    const collection = getDB().collection("medios");
    const id = new ObjectId(req.params.id);
    const current = await collection.findOne({ _id: id });
    if (!current) return res.status(404).json({ error: "Recurso no encontrado." });

    const item = parsePayload(req.body, req.files || {});
    if (!item.archivo_url) item.archivo_url = current.archivo_url || "";
    if (!item.caratula_url) item.caratula_url = current.caratula_url || "";

    await collection.updateOne({ _id: id }, { $set: item });
    res.json({ ...current, ...item, _id: id });
  } catch (err) { next(err); }
});

// DELETE /api/medios/:id
router.delete("/:id", async (req, res, next) => {
  try {
    if (!ObjectId.isValid(req.params.id)) return res.status(400).json({ error: "Identificador inválido." });
    const result = await getDB().collection("medios").deleteOne({ _id: new ObjectId(req.params.id) });
    if (!result.deletedCount) return res.status(404).json({ error: "Recurso no encontrado." });
    res.json({ mensaje: "Recurso eliminado correctamente." });
  } catch (err) { next(err); }
});

module.exports = router;
