require("dotenv").config();

const express = require("express");
const path = require("path");
const { connectDB, closeDB } = require("./database");
const mediosRouter = require("./routes/medios");

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = path.resolve(__dirname, "..");

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// La interfaz y los archivos multimedia se sirven desde el mismo servidor.
app.use(express.static(path.join(ROOT, "frontend")));
app.use("/almacenamiento", express.static(path.join(ROOT, "almacenamiento")));

app.get("/api/estado", (req, res) => res.json({ estado: "ok", servicio: "Biblioteca Multimedia API" }));
app.use("/api/medios", mediosRouter);

app.use((err, req, res, next) => {
  console.error(err);
  const status = err.name === "MulterError" ? 400 : 400;
  res.status(status).json({ error: err.message || "Ocurrió un error en el servidor." });
});

async function start() {
  try {
    await connectDB();
    const server = app.listen(PORT, () => {
      console.log(`Biblioteca disponible en http://localhost:${PORT}`);
    });

    const shutdown = async () => {
      server.close();
      await closeDB();
      process.exit(0);
    };
    process.on("SIGINT", shutdown);
    process.on("SIGTERM", shutdown);
  } catch (error) {
    console.error("No fue posible iniciar la aplicación:", error.message);
    process.exit(1);
  }
}

start();
