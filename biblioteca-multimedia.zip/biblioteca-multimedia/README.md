# Biblioteca Multimedia Digital

Aplicación web con HTML, CSS, JavaScript, Node.js, Express y MongoDB. Conserva la base `biblioteca_multimedia` y la colección `medios` del proyecto original.

## Requisitos

- Node.js 18 o superior
- Docker Desktop
- Visual Studio Code

## 1. Preparar variables

Copia `.env.example` y crea un archivo llamado `.env` en la raíz:

```bash
# Windows PowerShell
Copy-Item .env.example .env
```

Puedes cambiar la contraseña, pero debe coincidir con la que uses para iniciar MongoDB. Si ya existe un volumen de MongoDB inicializado con otras credenciales, conserva las credenciales originales.

## 2. Iniciar MongoDB

Desde la carpeta raíz del proyecto:

```bash
docker compose up -d
docker ps
```

Debe aparecer el contenedor `biblioteca_mongodb`.

## 3. Instalar dependencias

```bash
npm install
```

## 4. Cargar los datos de ejemplo (solo si aún no tienes datos)

El archivo `seed.js` contiene cinco registros de demostración. **No lo ejecutes si ya tienes información que quieras conservar**, porque la versión original elimina y vuelve a crear la colección.

Para copiarlo al contenedor y ejecutarlo:

```bash
docker cp seed.js biblioteca_mongodb:/tmp/seed.js
docker compose exec mongodb mongosh -u admin -p biblioteca123 --authenticationDatabase admin --file /tmp/seed.js
```

Si cambiaste `MONGO_USER` o `MONGO_PASSWORD` en `.env`, sustituye `admin` y `biblioteca123` por tus valores.

Si la base de datos ya contiene registros, omite este paso. La aplicación crea índices automáticamente al conectarse.

## 5. Iniciar la aplicación

```bash
npm run dev
```

Abre en el navegador:

```text
http://localhost:3000
```

También puedes iniciar con `npm start`.

## Funcionalidades

- Catálogo de libros, audiolibros, videos y música.
- Búsqueda por título, autor, género, descripción y etiquetas.
- Filtros por tipo y género.
- Alta, edición y eliminación de recursos.
- Carga de archivos PDF, MP3, WAV, OGG, MP4 y WEBM.
- Carga de carátulas JPG, PNG y WEBP.
- Reproductor de audio y video y visor de PDF.
- Favoritos guardados en el navegador.
- Estadísticas por tipo de recurso.

## API REST

| Método | Ruta | Función |
|---|---|---|
| GET | `/api/medios` | Consultar catálogo |
| GET | `/api/medios?q=quijote` | Buscar |
| GET | `/api/medios?tipo=libro` | Filtrar por tipo |
| GET | `/api/medios?genero=Novela` | Filtrar por género |
| GET | `/api/medios/estadisticas` | Estadísticas |
| GET | `/api/medios/:id` | Consultar un registro |
| POST | `/api/medios` | Agregar recurso |
| PUT | `/api/medios/:id` | Editar recurso |
| DELETE | `/api/medios/:id` | Eliminar recurso |

## Notas importantes

- Los archivos multimedia se guardan localmente en `almacenamiento/`; MongoDB conserva sus rutas.
- Los registros que ya tenías pueden seguir usando rutas como `almacenamiento/libros/archivo.pdf`. Para que se abran, coloca los archivos reales en esas carpetas.
- Los favoritos se guardan en el navegador, no en MongoDB.
- Esta versión es adecuada para desarrollo local. Antes de publicarla en internet, agrega autenticación, autorización, validación de archivos más estricta, límites de acceso y copias de seguridad.
- Si Docker ya tenía un volumen creado, modificar las variables del `.env` no cambia automáticamente el usuario y contraseña de ese volumen.
