// Consultas útiles para biblioteca_multimedia.medios
db = db.getSiblingDB("biblioteca_multimedia");

db.medios.createIndex({ titulo: "text", descripcion: "text", autor: "text", etiquetas: "text" });
db.medios.createIndex({ tipo: 1 });
db.medios.createIndex({ genero: 1 });
db.medios.createIndex({ etiquetas: 1 });

print("--- TODOS LOS RECURSOS ---");
db.medios.find({}, { titulo: 1, tipo: 1, autor: 1 }).pretty();

print("--- LIBROS ---");
db.medios.find({ tipo: "libro" }).pretty();

print("--- BÚSQUEDA POR TÍTULO: QUIJOTE ---");
db.medios.find({ titulo: /Quijote/i }).pretty();

print("--- BÚSQUEDA POR AUTOR ---");
db.medios.find({ autor: /Garcia|García/i }).pretty();

print("--- GÉNERO NOVELA ---");
db.medios.find({ genero: "Novela" }).pretty();

print("--- ETIQUETA CLÁSICO ---");
db.medios.find({ etiquetas: "clásico" }).pretty();

print("--- DESDE EL AÑO 1940 ---");
db.medios.find({ anio_publicacion: { $gte: 1940 } }).pretty();
